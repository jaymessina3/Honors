#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 22:05:50 2018

@author: JayMessina
"""
import re
import pandas
import openpyxl

import lxml.html as lh
import pandas as pd
from bs4 import BeautifulSoup
import requests

counting = 2

def getSheet(link_first, link_second, version, name, dist_feet, avg_speed):
    link = link_first + version + link_second
    a = requests.get(link)
    soup = BeautifulSoup(a.text, 'lxml')

    tb = soup.find("tbody")
    try:
        row = tb.findAll("tr")
    except:
        v = int(version) + 1
        version = "0" + str(v)
        #print (link + " " + version)
        getSheet(link_first, link_second, version, name, dist_feet, avg_speed)
        print(name)
        return
    global counting
    counting += 1
    print(name + " " + str(counting))
    labels = ['GM', 'Date', 'MP', 'FGA', 'FTA', 'dist_feet', 'avg_speed']
    
    bigL = []
    for x in row:
        items = x.findAll("td")
        counter = 0
        L = []
        for y in items:
            if (counter == 0 or counter == 1 or counter == 8 or counter == 10 or counter == 16):
                L.append(y.text)
            counter+=1
        L.append(dist_feet)
        L.append(avg_speed)
        bigL.append(L)

    df = pd.DataFrame.from_records(bigL, columns=labels)
    filename = name + ".xlsx"
    writer = pd.ExcelWriter(filename)
    df.to_excel(writer,'Sheet1')
    writer.save()
    

    

def main():
#dataset = pandas.read_excel("2013-2014_combined_fill.xlsx")
    book = openpyxl.Workbook()
    book = openpyxl.load_workbook('2013-2014_combined_fill.xlsx')
    sheet = book.get_sheet_by_name('Sheet1')   
    row_count = sheet.max_row
    for i in range (counting, row_count):
        s = sheet.cell(row=i, column=2).value
        if (s == None):
            continue
        #call function on s
        name = s[1:]
        name = re.sub(r'[^\w\s]','',name)
        arr = name.split(" ")
        version = "01"
        year = "2014"
        #column 5 and 6
        dist_feet = sheet.cell(row=i, column=5).value
        avg_speed = sheet.cell(row=i, column=6).value
        if (len(arr[1])>=5):
            link_first = ("https://www.basketball-reference.com/players/" + arr[0][0] + "/" + arr[1][0:5] + arr[0][0:2])
            #link_first += version
            link_second = "/gamelog/" + year + "/"
            link_first = link_first.lower()
            link_second = link_second.lower()
        else:
            link_first = ("https://www.basketball-reference.com/players/" + arr[0][0] + "/" + arr[1] + arr[0][0:2])
            link_second = "/gamelog/" + year + "/"
            link_first = link_first.lower()
            link_second = link_second.lower()
        f = name + "_" + year
        getSheet(link_first, link_second, version, f, dist_feet, avg_speed)
    
main()