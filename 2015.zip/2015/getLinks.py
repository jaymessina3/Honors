#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 22:05:50 2018

@author: JayMessina
"""
import re
import pandas
import openpyxl

import lxml.html as lh
import pandas as pd
from bs4 import BeautifulSoup
import requests

counting = 0

def getSheet(link, name, dist_feet, avg_speed):
    a = requests.get(link)
    soup = BeautifulSoup(a.text, 'lxml')
    
    tb = soup.find("tbody")
    try:
        row = tb.findAll("tr")
    except:
        print("bad " + name)
        
        return
    global counting
    counting += 1
    print(str(counting))
    labels = ['GM', 'Date', 'MP', 'FGA', 'FTA', 'dist_feet', 'avg_speed']
    
    bigL = []
    for x in row:
        items = x.findAll("td")
        counter = 0
        L = []
        for y in items:
            if (counter == 0 or counter == 1 or counter == 8 or counter == 10 or counter == 16):
                L.append(y.text)
            counter+=1
        L.append(dist_feet)
        L.append(avg_speed)
        bigL.append(L)

    df = pd.DataFrame.from_records(bigL, columns=labels)
    filename = name + ".xlsx"
    writer = pd.ExcelWriter(filename)
    df.to_excel(writer,'Sheet1')
    writer.save()
    

def badLink(book, sheet, row_count):    
    for i in range (2, row_count):
        s = sheet.cell(row=i, column=2).value
        if (s == None):
            continue
        #call function on s
        name = s[1:]
        name = re.sub(r'[^\w\s]','',name)
        arr = name.split(" ")
        version = "01"
        year = "2015"
        #column 5 and 6
        dist_feet = sheet.cell(row=i, column=5).value
        avg_speed = sheet.cell(row=i, column=6).value
        if (len(arr[1])>=5):
            link = ("https://www.basketball-reference.com/players/" + arr[0][0] + "/" + arr[1][0:5] + arr[0][0:2]+ version + "/gamelog/" + year + "/")
            link = link.lower()
        else:
            link = ("https://www.basketball-reference.com/players/" + arr[0][0] + "/" + arr[1] + arr[0][0:2]+ version + "/gamelog/" + year + "/")
            link = link.lower()
        f = name + "_" + year
        getSheet(link, f, dist_feet, avg_speed)

def main():
#dataset = pandas.read_excel("2013-2014_combined_fill.xlsx")
    book = openpyxl.Workbook()
    book = openpyxl.load_workbook('2014-2015_combined_fill.xlsx')
    sheet = book.get_sheet_by_name('Sheet1')   
    row_count = sheet.max_row
    
main()